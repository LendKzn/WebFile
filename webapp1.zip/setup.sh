#!/bin/bash

# ============================================
# WEB2APK GEN 3 - FULL VPS SETUP SCRIPT
# One Click Installation
# Includes: Node.js, Java, Gradle, Android SDK,
#           Flutter SDK, PM2, Local Bot API (2GB)
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m'

# Banner
echo ""
echo -e "${CYAN}${BOLD}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}${BOLD}║                                                                    ║${NC}"
echo -e "${CYAN}${BOLD}║        WEB2APK GEN 3 - FULL VPS SETUP (2GB SUPPORT)              ║${NC}"
echo -e "${CYAN}${BOLD}║                    One Click Installation                         ║${NC}"
echo -e "${CYAN}${BOLD}║                                                                    ║${NC}"
echo -e "${CYAN}${BOLD}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${YELLOW}⚠️  Not running as root. Some commands will use sudo.${NC}"
    echo ""
fi

# ============================================
# OS DETECTION
# ============================================
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_NAME=$ID
        OS_VERSION=$VERSION_ID
        OS_CODENAME=$VERSION_CODENAME
    else
        OS_NAME="unknown"
        OS_CODENAME="unknown"
    fi
}

detect_os

echo -e "${GREEN}✓ Detected OS: ${CYAN}$OS_NAME $OS_VERSION ($OS_CODENAME)${NC}"
echo ""

# ============================================
# PART 1: SYSTEM UPDATE & BASIC TOOLS
# ============================================
echo -e "${MAGENTA}${BOLD}[1/10] Updating system & installing basic tools...${NC}"
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git unzip zip nano htop \
    build-essential software-properties-common \
    apt-transport-https ca-certificates gnupg \
    lib32z1 lib32stdc++6 xz-utils libglu1-mesa \
    clang cmake ninja-build pkg-config libgtk-3-dev
echo -e "${GREEN}✓ System updated & basic tools installed${NC}"
echo ""

# ============================================
# PART 2: NODE.JS 20
# ============================================
echo -e "${MAGENTA}${BOLD}[2/10] Installing Node.js 20...${NC}"
if ! command -v node &> /dev/null || [[ $(node -v | cut -d. -f1 | tr -d 'v') -lt 18 ]]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi
echo -e "${GREEN}✓ Node.js $(node -v) installed${NC}"
echo -e "${GREEN}✓ npm v$(npm -v)${NC}"
echo ""

# ============================================
# PART 3: JAVA 17
# ============================================
echo -e "${MAGENTA}${BOLD}[3/10] Installing Java 17...${NC}"

if [ "$OS_NAME" = "debian" ]; then
    echo -e "${YELLOW}  Debian detected - Installing Eclipse Temurin JDK 17...${NC}"
    sudo apt install -y wget apt-transport-https gnupg
    
    if [ ! -f /usr/share/keyrings/adoptium.gpg ]; then
        wget -qO - https://packages.adoptium.net/artifactory/api/gpg/key/public | sudo gpg --dearmor -o /usr/share/keyrings/adoptium.gpg
    fi
    
    if [ ! -f /etc/apt/sources.list.d/adoptium.list ]; then
        echo "deb [signed-by=/usr/share/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb $OS_CODENAME main" | sudo tee /etc/apt/sources.list.d/adoptium.list
    fi
    
    sudo apt update
    sudo apt install -y temurin-17-jdk
    JAVA_HOME="/usr/lib/jvm/temurin-17-jdk-amd64"
else
    sudo apt install -y openjdk-17-jdk
    JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"
fi

echo "JAVA_HOME=$JAVA_HOME" | sudo tee -a /etc/environment
export JAVA_HOME=$JAVA_HOME
echo -e "${GREEN}✓ $(java -version 2>&1 | head -n1)${NC}"
echo -e "${GREEN}✓ JAVA_HOME=$JAVA_HOME${NC}"
echo ""

# ============================================
# PART 4: GRADLE 8.7
# ============================================
echo -e "${MAGENTA}${BOLD}[4/10] Installing Gradle 8.7...${NC}"
GRADLE_VERSION="8.7"
cd /tmp
if [ ! -f "/opt/gradle-$GRADLE_VERSION/bin/gradle" ]; then
    wget -q "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -O gradle.zip
    sudo unzip -q -d /opt gradle.zip
    sudo ln -sf /opt/gradle-${GRADLE_VERSION}/bin/gradle /usr/local/bin/gradle
    rm gradle.zip
fi
echo -e "${GREEN}✓ Gradle $(gradle -v 2>/dev/null | grep Gradle | awk '{print $2}')${NC}"
echo ""

# ============================================
# PART 5: ANDROID SDK
# ============================================
echo -e "${MAGENTA}${BOLD}[5/10] Setting up Android SDK...${NC}"
ANDROID_HOME="/opt/android-sdk"
sudo mkdir -p $ANDROID_HOME/cmdline-tools
cd $ANDROID_HOME/cmdline-tools

if [ ! -d "latest" ]; then
    sudo wget -q "https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip" -O tools.zip
    sudo unzip -q tools.zip
    if [ -d "cmdline-tools" ]; then
        sudo mv cmdline-tools latest
    fi
    sudo rm -f tools.zip
fi

sudo chmod -R 777 $ANDROID_HOME
export ANDROID_HOME=$ANDROID_HOME
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

echo -e "${YELLOW}  Installing SDK components (this may take 5-10 minutes)...${NC}"
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses > /dev/null 2>&1 || true

$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager \
    "platforms;android-34" \
    "platforms;android-35" \
    "build-tools;34.0.0" \
    "build-tools;35.0.0" \
    "platform-tools" \
    "ndk;27.0.12077973" \
    "cmake;3.22.1" > /dev/null 2>&1

echo "ANDROID_HOME=$ANDROID_HOME" | sudo tee -a /etc/environment
echo -e "${GREEN}✓ Android SDK installed at $ANDROID_HOME${NC}"
echo -e "${GREEN}✓ NDK 27.0.12077973 installed${NC}"
echo ""

# ============================================
# PART 6: FLUTTER SDK
# ============================================
echo -e "${MAGENTA}${BOLD}[6/10] Installing Flutter SDK...${NC}"
FLUTTER_HOME="/opt/flutter"

if [ ! -d "$FLUTTER_HOME" ]; then
    cd /opt
    sudo git clone https://github.com/flutter/flutter.git -b stable --depth 1
    sudo chmod -R 777 $FLUTTER_HOME
fi

export PATH=$PATH:$FLUTTER_HOME/bin
flutter precache --android > /dev/null 2>&1 || true

echo "FLUTTER_HOME=$FLUTTER_HOME" | sudo tee -a /etc/environment
echo -e "${GREEN}✓ Flutter $(flutter --version 2>/dev/null | head -n1 | awk '{print $2}') installed${NC}"
echo ""

# ============================================
# PART 7: PM2
# ============================================
echo -e "${MAGENTA}${BOLD}[7/10] Installing PM2...${NC}"
sudo npm install -g pm2 > /dev/null 2>&1
echo -e "${GREEN}✓ PM2 $(pm2 --version) installed${NC}"
echo ""

# ============================================
# PART 8: ENVIRONMENT VARIABLES
# ============================================
echo -e "${MAGENTA}${BOLD}[8/10] Setting up environment variables...${NC}"

# Clean old entries
sudo sed -i '/JAVA_HOME/d' /etc/environment 2>/dev/null || true
sudo sed -i '/ANDROID_HOME/d' /etc/environment 2>/dev/null || true
sudo sed -i '/FLUTTER_HOME/d' /etc/environment 2>/dev/null || true

# Add new entries
echo "JAVA_HOME=$JAVA_HOME" | sudo tee -a /etc/environment > /dev/null
echo "ANDROID_HOME=$ANDROID_HOME" | sudo tee -a /etc/environment > /dev/null
echo "FLUTTER_HOME=$FLUTTER_HOME" | sudo tee -a /etc/environment > /dev/null

# Add to bashrc
if ! grep -q "export FLUTTER_HOME" ~/.bashrc 2>/dev/null; then
    cat >> ~/.bashrc << EOF

# Web2APK Environment
export JAVA_HOME=$JAVA_HOME
export ANDROID_HOME=$ANDROID_HOME
export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973
export FLUTTER_HOME=$FLUTTER_HOME
export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$FLUTTER_HOME/bin
EOF
fi

echo -e "${GREEN}✓ Environment variables configured${NC}"
echo ""

# ============================================
# PART 9: TELEGRAM LOCAL BOT API SERVER (2GB)
# ============================================
echo -e "${MAGENTA}${BOLD}[9/10] Setting up Telegram Local Bot API Server (2GB support)...${NC}"
echo ""

# Ask for API credentials
echo -e "${CYAN}┌─────────────────────────────────────────────────────────────┐${NC}"
echo -e "${CYAN}│  Telegram Local Bot API Server Setup                        │${NC}"
echo -e "${CYAN}│  This allows file uploads/downloads up to 2GB!             │${NC}"
echo -e "${CYAN}└─────────────────────────────────────────────────────────────┘${NC}"
echo ""
echo -e "${YELLOW}Get your API credentials from: https://my.telegram.org${NC}"
echo -e "${YELLOW}1. Login with your Telegram account${NC}"
echo -e "${YELLOW}2. Go to 'API Development Tools'${NC}"
echo -e "${YELLOW}3. Create a new application${NC}"
echo ""

read -p "Enter your API_ID: " API_ID
read -p "Enter your API_HASH: " API_HASH

if [ -z "$API_ID" ] || [ -z "$API_HASH" ]; then
    echo -e "${RED}❌ API_ID and API_HASH are required!${NC}"
    echo -e "${YELLOW}You can run this script again or manually setup later.${NC}"
else
    echo ""
    echo -e "${YELLOW}📦 Installing build dependencies...${NC}"
    sudo apt-get install -y make git zlib1g-dev libssl-dev gperf cmake g++ build-essential > /dev/null 2>&1

    echo -e "${YELLOW}📥 Cloning Telegram Bot API repository...${NC}"
    cd /opt
    if [ -d "telegram-bot-api" ]; then
        cd telegram-bot-api
        sudo git pull > /dev/null 2>&1
    else
        sudo git clone --recursive https://github.com/tdlib/telegram-bot-api.git > /dev/null 2>&1
        cd telegram-bot-api
    fi

    echo -e "${YELLOW}🔨 Building Telegram Bot API Server...${NC}"
    echo -e "${YELLOW}   This will take 10-30 minutes depending on your VPS specs...${NC}"
    sudo rm -rf build
    sudo mkdir build
    cd build
    sudo cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX:PATH=/usr/local .. > /dev/null 2>&1
    sudo cmake --build . --target install -j $(nproc) > /dev/null 2>&1

    echo -e "${YELLOW}📝 Creating systemd service...${NC}"
    sudo cat > /etc/systemd/system/telegram-bot-api.service << EOF
[Unit]
Description=Telegram Bot API Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/telegram-bot-api --api-id=${API_ID} --api-hash=${API_HASH} --local --http-port=8081 --max-webhook-connections=100 --workers=4
Restart=always
RestartSec=5
User=root
WorkingDirectory=/opt/telegram-bot-api

[Install]
WantedBy=multi-user.target
EOF

    echo -e "${YELLOW}🚀 Starting Telegram Bot API Server...${NC}"
    sudo systemctl daemon-reload
    sudo systemctl enable telegram-bot-api > /dev/null 2>&1
    sudo systemctl start telegram-bot-api

    sleep 5

    if systemctl is-active --quiet telegram-bot-api; then
        echo -e "${GREEN}✓ Local Bot API Server is running on: http://localhost:8081${NC}"
    else
        echo -e "${RED}❌ Failed to start Telegram Bot API Server${NC}"
        echo -e "${YELLOW}   Check logs: journalctl -u telegram-bot-api -e${NC}"
    fi
fi
echo ""

# ============================================
# PART 10: FINAL SETUP & VERIFICATION
# ============================================
echo -e "${MAGENTA}${BOLD}[10/10] Finalizing setup & verification...${NC}"
source ~/.bashrc 2>/dev/null || true

echo ""
echo -e "${GREEN}${BOLD}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║                    SETUP COMPLETE!                             ║${NC}"
echo -e "${GREEN}${BOLD}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}${BOLD}📦 INSTALLED COMPONENTS:${NC}"
echo -e "${GREEN}  ✓ Node.js:     $(node -v)${NC}"
echo -e "${GREEN}  ✓ npm:         v$(npm -v)${NC}"
echo -e "${GREEN}  ✓ Java:        $(java -version 2>&1 | head -n1 | cut -d'"' -f2)${NC}"
echo -e "${GREEN}  ✓ Gradle:      $(gradle -v 2>/dev/null | grep Gradle | awk '{print $2}')${NC}"
echo -e "${GREEN}  ✓ Android SDK: $ANDROID_HOME${NC}"
echo -e "${GREEN}  ✓ Flutter:     $(flutter --version 2>/dev/null | head -n1 | awk '{print $2}')${NC}"
echo -e "${GREEN}  ✓ PM2:         $(pm2 --version)${NC}"
if systemctl is-active --quiet telegram-bot-api 2>/dev/null; then
    echo -e "${GREEN}  ✓ Local Bot API: Running on http://localhost:8081${NC}"
else
    echo -e "${YELLOW}  ⚠ Local Bot API: Not installed or not running${NC}"
fi
echo ""

echo -e "${CYAN}${BOLD}📝 NEXT STEPS:${NC}"
echo ""
echo -e "${YELLOW}1. Apply environment variables:${NC}"
echo -e "   ${GREEN}source ~/.bashrc${NC}"
echo ""
echo -e "${YELLOW}2. Clone your project:${NC}"
echo -e "   ${GREEN}git clone https://github.com/yourusername/web2apk.git${NC}"
echo -e "   ${GREEN}cd web2apk${NC}"
echo -e "   ${GREEN}npm install${NC}"
echo -e "   ${GREEN}cp .env.example .env${NC}"
echo ""
echo -e "${YELLOW}3. Edit .env file:${NC}"
echo -e "   ${GREEN}nano .env${NC}"
echo ""
echo -e "${YELLOW}4. Add to .env (if Local Bot API installed):${NC}"
echo -e "   ${GREEN}LOCAL_API_URL=http://localhost:8081${NC}"
echo -e "   ${GREEN}API_ID=$API_ID${NC}"
echo -e "   ${GREEN}API_HASH=$API_HASH${NC}"
echo ""
echo -e "${YELLOW}5. Start your bot with PM2:${NC}"
echo -e "   ${GREEN}pm2 start src/bot.js --name web2apk${NC}"
echo -e "   ${GREEN}pm2 save${NC}"
echo -e "   ${GREEN}pm2 startup${NC}"
echo ""

echo -e "${CYAN}${BOLD}🔧 USEFUL COMMANDS:${NC}"
echo -e "  ${GREEN}pm2 list${NC}                    - List all running processes"
echo -e "  ${GREEN}pm2 logs web2apk${NC}            - View bot logs"
echo -e "  ${GREEN}pm2 monit${NC}                   - Monitor CPU/Memory"
echo -e "  ${GREEN}systemctl status telegram-bot-api${NC} - Check Local Bot API status"
echo -e "  ${GREEN}journalctl -u telegram-bot-api -f${NC} - View Local Bot API logs"
echo ""

echo -e "${CYAN}${BOLD}✅ All done! Your VPS is ready for Web2APK Gen 3!${NC}"
echo ""